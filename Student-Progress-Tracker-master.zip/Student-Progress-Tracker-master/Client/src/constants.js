//export const API_ENDPOINT = "http://localhost:5000/"
export const API_ENDPOINT = "https://student-progress-tracker-main-server.onrender.com/"
